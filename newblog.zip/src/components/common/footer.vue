<template lang="html">
  <footer>
      <p>
        vue2.0 模仿 Theme by Yumemor. Powered by Hexo
      </p>
  </footer>
</template>

<style lang="css">
  footer {
    background:#f5f5f5;
    padding: 26px 0;
    color:#aaa;
    font-size:16px;
    text-align: center;
    clear: both;
  }
</style>
